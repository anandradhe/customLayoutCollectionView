//
//  AKASegmentView.swift
//  SegmentControlUsingCollectionView
//
//  Created by User1 on 29/05/18.
//  Copyright © 2018 User1. All rights reserved.
//

import UIKit

class AKASegmentView: UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout  {
 
   open  var noOfSegments = 2
   open var selectedIndexPath = IndexPath(item: 0, section: 0)
   open var selectedSegmentColor = UIColor.red
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
        return noOfSegments
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
        
        return cell
    }
    
//    func createTitleLabel(view:UIView) -> UILabel {
//        
//        let lbl = UILabel(frame: CGRect.zero)
//        lbl.textColor = UIColor.black
//        lbl.numberOfLines = 1
//        
//        
//    }

    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

//class AKASegmentCell: UICollectionViewCell {
//     weak var lblTitle: UILabel!
//     weak var bottomView: UIView!
//
//}
