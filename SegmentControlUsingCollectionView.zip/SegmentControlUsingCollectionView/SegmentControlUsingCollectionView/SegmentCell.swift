//
//  SegmentCell.swift
//  SegmentControlUsingCollectionView
//
//  Created by User1 on 29/05/18.
//  Copyright © 2018 User1. All rights reserved.
//

import UIKit

class SegmentCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var bottomView: UIView!
    
}
