//
//  ViewController.swift
//  SegmentControlUsingCollectionView
//
//  Created by User1 on 29/05/18.
//  Copyright © 2018 User1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var segmentCollectionView: UICollectionView!
    var noOfSegments = 10
    var selectedIndexPath = IndexPath(item: 0, section: 0)
    var selectedSegmentColor = UIColor.red

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
   segmentCollectionView.layer.masksToBounds = true
        segmentCollectionView.layer.shadowColor = UIColor.red.cgColor

        segmentCollectionView.layer.shadowRadius = 2
        segmentCollectionView.layer.shadowOpacity = 1
        segmentCollectionView.layer.shadowOffset = CGSize.zero
        segmentCollectionView.layer.shadowRadius = 5
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController:UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return noOfSegments
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! SegmentCell
        cell.bottomView.backgroundColor = (selectedIndexPath == indexPath) ? selectedSegmentColor : UIColor.clear
        cell.lblTitle.text = "Segment \(indexPath.row)"
        return  cell
        
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = CGSize(width: collectionView.frame.size.width / CGFloat( noOfSegments), height: collectionView.frame.size.height)
        return size
        
    }
}

extension ViewController:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndexPath = indexPath
        collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
    }
}
